class CreateWebStatics < ActiveRecord::Migration
  def self.up
    create_table :web_statics do |t|
      t.column :access_time,    :integer, :null => false, :default => 0
    end
      WebStatic.create(:access_time =>0)
  end

  def self.down
    drop_table :web_statics
  end
end