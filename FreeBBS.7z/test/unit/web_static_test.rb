require File.dirname(__FILE__) + '/../test_helper'

class WebStaticTest < Test::Unit::TestCase
  fixtures :web_statics

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
