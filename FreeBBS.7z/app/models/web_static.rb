class WebStatic < ActiveRecord::Base
  def self.find_static
        for static_time in find(:all)
        end
        static_time
  end

  def self.get_total_access_time
      self.find_static.access_time
  end

  def self.get_user_active
     Session.count(:conditions => ["updated_at > ?", 30.minutes.ago])
  end
end
