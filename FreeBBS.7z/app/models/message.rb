class Message < ActiveRecord::Base
  def self.find_messages
    find(:all)
  end
end
