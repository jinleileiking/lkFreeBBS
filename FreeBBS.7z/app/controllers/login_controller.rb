class LoginController < ApplicationController

    before_filter :init
    after_filter :after
    
    def init
        @user_total = User.find(:all).length
        @total_access_time = WebStatic.get_total_access_time
        @posts = Message.paginate :per_page => 30, :page => params[:page], :order => "posted_at ASC"

        if session[:loggin_name]
               puts session[:loggin_name]
               @user_active = WebStatic.get_user_active
               puts @user_active
        end

        
    end

    def after
    end

    def index
        
        static_time =WebStatic.find_static
            static_time.access_time = static_time.access_time + 1
            static_time.save

        
    end

    def login_pushed
        user = User.find_by_name(params[:user][:name])
        if user && params[:user][:password] == user.password
            session[:loggin_name] = user.name
            redirect_to :action => :index
            return
        end

        flash[:notice] = "请检查用户名和密码"
        redirect_to :action => :index

    end


    def register

    end

    def add_user

        if User.new(params[:user]).save
            flash[:notice] = "恭喜! 账号已建立"
            redirect_to :action => :index
            return
        end
        
        flash[:notice] = "账号未建立！请检查"
        redirect_to :action => :register

    end

    def logout
        session[:loggin_name] = nil
        puts session[:loggin_name]
        redirect_to :action => :index
        

    end

    def add_message
        if Message.new({:name => session[:loggin_name], :posted_at =>Time.now }.merge(params[:messagebox])).save
            flash[:notice] = "发表成功"
            redirect_to :action => :index
            return
        end
    end
end
